# 迭代 9：设置、Provider 与数据闭环

## 迭代目标

完成设置页和数据闭环能力，包括 Provider 状态、默认模型、角色专属模型、Prompt 配置、本地数据与导出。

本迭代使产品从“核心讨论可用”走向“可被真实用户持续使用”。

## 原型映射

| 原型区域 | 本迭代要求 |
|---|---|
| 设置页 Provider 状态 | 展示 OpenAI、Anthropic、Gemini、DeepSeek 连接状态 |
| 模型与 Provider | 管理 Provider、Base URL、API Key |
| 全局默认模型 | 配置默认模型和参数 |
| 角色专属模型 | 为角色指定模型 |
| 模板管理 | 新建、导入、导出模板入口 |
| Prompt 配置 | 全局提示词与角色提示词 |
| 本地数据与安全 | 会话导出、清理、隐私说明 |
| 会话页导出 | 导出会话为 Markdown |

## 前端需求

| 编号 | 需求 |
|---|---|
| FE-001 | 实现设置页完整分组布局 |
| FE-002 | 展示 Provider 连接状态 |
| FE-003 | 实现 Provider 配置 Sheet：provider、baseUrl、apiKey |
| FE-004 | 实现默认模型配置 Sheet：model、temperature、maxTokens |
| FE-005 | 实现角色专属模型配置 Sheet |
| FE-006 | 实现 Prompt 配置入口，支持查看和编辑全局 Prompt |
| FE-007 | 实现模板导入/导出入口 |
| FE-008 | 实现本地数据清理入口 |
| FE-009 | 会话页支持导出当前会话为 Markdown |
| FE-010 | 敏感信息如 API Key 默认脱敏展示 |

## 后端/API需求

| 编号 | 需求 |
|---|---|
| BE-001 | 实现 `GET /api/llm/providers` 获取 Provider 状态 |
| BE-002 | 实现 `POST /api/llm/providers/test` 测试连接 |
| BE-003 | 实现 `PUT /api/settings/model-defaults` 保存默认模型 |
| BE-004 | 实现 `PUT /api/settings/role-models` 保存角色模型配置 |
| BE-005 | 实现 `GET /api/settings/prompts` 和 `PUT /api/settings/prompts` |
| BE-006 | 实现 `GET /api/sessions/:sessionId/export?format=md` |
| BE-007 | 实现本地/服务端设置仓储接口 |
| BE-008 | API Key 不返回明文，只返回 maskedKey |
| BE-009 | LLMClient 从设置读取 Provider 和模型配置 |
| BE-010 | 提供设置导入/导出 JSON 的服务接口 |

## 安全与数据要求

| 编号 | 要求 |
|---|---|
| SEC-001 | API Key 前端展示必须脱敏 |
| SEC-002 | 真实 API Key 不进入日志 |
| SEC-003 | 导出会话不包含 API Key |
| SEC-004 | 清理本地数据前必须确认 |
| SEC-005 | Provider 测试失败时返回可解释错误 |

## 验收标准

| 类型 | 标准 |
|---|---|
| 产品 | 设置页展示 Provider、模型、模板、Prompt、本地数据分组 |
| 产品 | 用户可查看 Provider 状态 |
| 产品 | 用户可测试 Provider 连接 |
| 产品 | 用户可设置全局默认模型 |
| 产品 | 用户可为角色设置专属模型 |
| 产品 | 用户可导出会话为 Markdown |
| 产品 | API Key 脱敏展示 |
| 产品 | 清理数据前有二次确认 |
| 技术 | Provider 设置能被 LLMClient 使用 |
| 技术 | Provider 测试接口可返回成功或具体失败原因 |
| 技术 | 默认模型配置能影响新会话 |
| 技术 | 角色模型配置能影响对应 Agent |
| 技术 | 会话导出 Markdown 内容完整 |
| 技术 | API Key 不进入日志和导出内容 |
| 技术 | e2e 覆盖 Provider 配置、默认模型设置、会话导出 |

## 不包含范围

| 不包含 | 说明 |
|---|---|
| 企业级权限系统 | 后续版本 |
| 多设备同步 | Phase 3 |
| 付费计费系统 | 后续商业化 |
| 模板市场 | 后续产品化 |

## 需求评审关注点

1. Provider 配置是否与 LLMClient 打通。
2. API Key 是否安全处理。
3. 会话导出是否满足用户留存需求。
4. 设置页是否保持移动端简洁，不变成复杂后台。
