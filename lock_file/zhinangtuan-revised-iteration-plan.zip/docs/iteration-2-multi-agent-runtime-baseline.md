# 迭代 2：多 Agent 运行时基础架构

## 迭代目标

建立产品的核心智能架构：多 Agent 讨论运行时。完成 Host Agent、Expert Agent、Critic Agent 的基础抽象，实现多个角色围绕同一议题串行发言。

本迭代重点在后端/API/引擎能力，前端只需能触发讨论生成并展示基础结果。

## 原型映射

| 原型区域 | 本迭代要求 |
|---|---|
| 讨论页角色栏 | 能展示模板中的主持人和角色 |
| 讨论页消息流 | 能展示第一轮多角色发言 |
| 讨论页标题 | 显示当前会话议题 |
| 发送输入 | 暂只支持基础消息提交 |
| 事件卡/邀请卡 | 可用 Mock 占位，不要求真实触发 |

## 前端需求

| 编号 | 需求 |
|---|---|
| FE-001 | 讨论页通过 sessionId 加载会话详情 |
| FE-002 | 展示会话标题、模板名称、角色栏 |
| FE-003 | 展示 Host Agent 开场消息 |
| FE-004 | 展示多个角色的基础发言消息 |
| FE-005 | 用户发送消息后，页面展示用户消息和系统生成的下一条角色消息 |
| FE-006 | 消息气泡区分主持人、角色、用户 |
| FE-007 | 当前发言角色在角色栏高亮 |
| FE-008 | 生成中显示 Loading 或 Typing 状态 |
| FE-009 | LLM 失败时展示错误提示和重试入口 |
| FE-010 | 页面预留 EventCard 和 InviteCard 容器 |

## 后端/API/引擎需求

| 编号 | 需求 |
|---|---|
| BE-001 | 实现 `GET /api/sessions/:sessionId` 获取会话详情 |
| BE-002 | 实现 `GET /api/discussions/:sessionId/messages` 获取消息列表 |
| BE-003 | 实现 `POST /api/discussions/:sessionId/messages` 发送用户消息并触发下一轮 Agent 发言 |
| BE-004 | 实现 `AgentProfile`：角色身份、人设、Prompt、模型、温度 |
| BE-005 | 实现 `AgentRuntime`：接收上下文并生成 AgentOutput |
| BE-006 | 实现 `Orchestrator`：统一调度 Host、Expert、Critic |
| BE-007 | 实现基础 `Scheduler`：默认串行轮转角色 |
| BE-008 | 实现上下文构造：topic、template、role prompt、message history |
| BE-009 | 实现 LLM Client 统一入口；支持 MockLLM 和真实 Provider 两种模式 |
| BE-010 | 记录 Agent 调用结果，包括输入摘要、输出、耗时、错误 |
| BE-011 | 本迭代默认自研轻量 Agent 编排，不引入 LangGraph/AutoGen/CrewAI 作为主依赖 |
| BE-012 | 预留并行 Agent 接口，但默认采用串行执行 |

## Agent 架构基线

```text
User Topic
  ↓
SessionService
  ↓
DiscussionOrchestrator
  ├─ HostAgent
  ├─ ExpertAgent[]
  └─ CriticAgent
  ↓
Scheduler
  ↓
LLMClient / MockLLMClient
  ↓
Message Repository
```

## 验收标准

| 类型 | 标准 |
|---|---|
| 产品 | 一个会话中至少能看到主持人和 3 个角色 |
| 产品 | 点击开始讨论后，主持人能发出开场消息 |
| 产品 | 多个角色能围绕同一议题输出不同观点 |
| 产品 | 用户发送消息后，系统能继续生成角色回应 |
| 产品 | 角色发言不能全部像同一个人，至少体现角色差异 |
| 产品 | 生成失败时用户可看到明确错误提示 |
| 技术 | Orchestrator、Scheduler、AgentRuntime 模块存在且职责清晰 |
| 技术 | UI 不直接调用 LLM，必须通过 API/Service/Engine |
| 技术 | 支持 MockLLM 模式，测试环境无需真实 API Key |
| 技术 | 消息按 sessionId 正确隔离 |
| 技术 | 每次 Agent 生成有基本调用记录 |
| 技术 | 单元测试覆盖角色调度、上下文构造、MockLLM 输出 |

## 不包含范围

| 不包含 | 说明 |
|---|---|
| 完整状态机 | 迭代 4 实现 |
| 用户意图识别 | 迭代 5 实现 |
| 导演逻辑 | 迭代 6 实现 |
| 爽点事件 | 迭代 7 实现 |
| 模板配置 UI | 迭代 8 实现 |

## 需求评审关注点

1. 是否采用自研轻量 Agent 架构，而不是过早引入复杂开源 Agent 框架。
2. Host / Expert / Critic 是否有明确职责。
3. 上下文拼接是否可控，避免 token 无限增长。
4. MockLLM 是否能支撑自动化测试。
5. 多 Agent 运行时是否可以被后续状态机、导演逻辑和事件机制复用。
